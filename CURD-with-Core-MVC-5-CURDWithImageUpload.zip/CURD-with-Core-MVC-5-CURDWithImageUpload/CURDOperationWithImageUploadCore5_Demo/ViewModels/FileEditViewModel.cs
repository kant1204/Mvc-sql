﻿namespace CURDOperationWithImageUploadCore5_Demo.ViewModels
{
    public class FileEditViewModel : FileUploadViewModel
    {
        public int Id { get; set; }
        public string ExistingImage { get; set; }
    }
}
